# Mobile-only APK build

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

On a phone, upload the project to a GitHub repository, open the **Actions** tab, run **Build Android APK**, and download the generated APK from the workflow's **Artifacts** section.
