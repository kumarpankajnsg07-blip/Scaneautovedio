package com.mithun.sceneautovideo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

data class Scene(val number:Int, val prompt:String)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var apiKey by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var scenes by remember { mutableStateOf(listOf<Scene>()) }
    var status by remember { mutableStateOf("Ready") }
    var running by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme {
        Scaffold(topBar={TopAppBar(title={Text("Scene Auto Video • Veo")})}) { p ->
            LazyColumn(
                Modifier.fillMaxSize().padding(p).padding(16.dp),
                verticalArrangement=Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Gemini API Key", style=MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        apiKey, { apiKey=it }, Modifier.fillMaxWidth(),
                        singleLine=true, placeholder={Text("AIza...")}
                    )
                    Text("Prototype: key is used locally for requests. For a public production app, move API calls to a secure backend.",
                        style=MaterialTheme.typography.bodySmall)
                }
                item {
                    Text("Story / Song / Content", style=MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        content, { content=it },
                        Modifier.fillMaxWidth().height(180.dp),
                        placeholder={Text("Pura content yahan paste karein...")}
                    )
                }
                item {
                    Button(
                        onClick={
                            scenes = SceneEngine.split(content)
                            status="${scenes.size} scenes ready"
                        },
                        modifier=Modifier.fillMaxWidth()
                    ){ Text("CREATE SCENES") }
                }
                item {
                    Button(
                        enabled=scenes.isNotEmpty() && apiKey.isNotBlank() && !running,
                        onClick={
                            running=true
                            status="Starting Veo queue..."
                            scope.launch {
                                var ok=0
                                scenes.forEachIndexed { i, scene ->
                                    status="Generating Scene ${i+1}/${scenes.size}..."
                                    val result=VeoApi.generate(apiKey, scene.prompt)
                                    if(result.startsWith("OK")) ok++
                                    else status="Scene ${i+1} failed: $result"
                                }
                                status="Queue finished: $ok/${scenes.size} submitted successfully."
                                running=false
                            }
                        },
                        modifier=Modifier.fillMaxWidth()
                    ){ Text(if(running) "GENERATING..." else "GENERATE ALL WITH VEO") }
                }
                item { Text(status) }
                items(scenes) { s ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Scene ${s.number}", style=MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(5.dp))
                            Text(s.prompt)
                        }
                    }
                }
            }
        }
    }
}

object SceneEngine {
    fun split(text:String):List<Scene> {
        if(text.isBlank()) return emptyList()
        val parts=text.split(Regex("""(?<=[.!?।])\s+|\n+"""))
            .map{it.trim()}.filter{it.isNotBlank()}
        return parts.mapIndexed { i, x ->
            Scene(i+1,
                """Cinematic 16:9 video. Keep the same characters, faces, hairstyles, body proportions and costumes as the supplied references. No face change or redesign. Scene action: $x. Natural acting, smooth camera movement, realistic expressions and gestures, high detail, consistent environment. Generate appropriate dialogue/audio only when clearly present."""
            )
        }
    }
}

object VeoApi {
    private const val MODEL="veo-3.1-generate-preview"
    private const val BASE="https://generativelanguage.googleapis.com/v1beta"

    suspend fun generate(key:String, prompt:String):String = withContext(Dispatchers.IO) {
        try {
            val url=URL("$BASE/models/$MODEL:predictLongRunning")
            val c=url.openConnection() as HttpURLConnection
            c.requestMethod="POST"
            c.setRequestProperty("x-goog-api-key", key.trim())
            c.setRequestProperty("Content-Type","application/json")
            c.doOutput=true
            val body=JSONObject()
                .put("instances", org.json.JSONArray().put(JSONObject().put("prompt",prompt)))
                .put("parameters", JSONObject().put("aspectRatio","16:9").put("resolution","720p"))
                .toString()
            c.outputStream.use{it.write(body.toByteArray())}
            val code=c.responseCode
            val stream=if(code in 200..299)c.inputStream else c.errorStream
            val text=BufferedReader(InputStreamReader(stream)).use{it.readText()}
            if(code in 200..299) "OK: $text" else "HTTP $code: $text"
        } catch(e:Exception) {
            "ERROR: ${e.message}"
        }
    }
}
