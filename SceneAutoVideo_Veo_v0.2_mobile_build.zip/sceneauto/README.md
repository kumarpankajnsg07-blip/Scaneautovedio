# Scene Auto Video — Veo 3.1 MVP v0.2

This build adds a real Gemini API request path for Veo 3.1.

## Use
1. Open the project in Android Studio.
2. Build/install the app.
3. Enter your Gemini API key.
4. Paste your story/song.
5. CREATE SCENES.
6. GENERATE ALL WITH VEO.

The app sends each scene as a 16:9 Veo 3.1 long-running generation request.

## Important
This is a prototype. It currently submits jobs and reports the returned operation response. A production version should add:
- operation polling until done
- secure backend/API-key storage
- video download
- local clip storage
- retry
- reference image upload / base64 handling
- automatic MP4 concatenation
- cost/rate-limit handling

Google's current Veo 3.1 Gemini API documentation specifies asynchronous generation, 16:9 support, and reference-image support. See:
https://ai.google.dev/gemini-api/docs/veo
